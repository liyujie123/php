<?php
namespace Admin\Model;
use Think\Model;
class ManagerModel extends Model
{   
   //登陆时表单验证的规则
   public $_login_validate = array(
   	   array('mg_name','require','用户名不能为空!',1),
   	   array('mg_pwd','require','密码不能为空!',1),
   	   array('chkcode','require','验证码不能为空!',1),
   	   array('chkcode','chk_chkcode','验证码不正确!',1,'callback'),
   	);
   //添加和修改管理员时的规则
   public $_validate = array(

   	);

   public function chk_chkcode($code)
   {
   	  $verify = new \Think\Verify();
   	  return $verify->check($code);
   }

   public function login(){
   	  //获取表单中的用户名密码
   	  $username = $this->mg_name;
   	  $password = $this->mg_pwd;
   	  //先查询数据库有没有这个账号
   	  $user = $this->where(array('mg_name' => array('eq',$username), ))->find();
   	  //判断有没有账号
   	  if($user) 
   	  {    
           	 //判断密码
           	 if($user['mg_pwd']==md5($password.C('MD5_KEY')))
           	 {
           	 	 //把ID和用户名存到session中
                 session('admin_id',$user['mg_id']);
                 session('admin_user',$user['mg_name']);
                 return TRUE;
           	 }
           	 else
           	 {
           	 	 $this->error = '密码错误！';
                 return FALSE;
           	 }
           }
   	  else
   	  {
           $this->error = '用户名不存在！';
           return FALSE;
   	  }
   }
}