<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
     public function denglu(){
	   if(!empty($_POST)){
	      $username = mysql_real_escape_string($_POST['username']);
		  $password = mysql_real_escape_string($_POST['password']);
		  $verify = new \Think\Verify();
		  if($verify->check($_POST['yan'])){
		   $user = D('user');
		   mysql_query("SET NAMES gb2312");
		   $info = $user -> where("username='$username' and password='$password'") -> find();
		  if($info){
		      session('user',$username);
		      $this->redirect('index');
		  }else{
		      echo "<script>alert('用户名或密码错误！')</script>";
		  }
		  }else{
		      echo "<script>alert('验证码错误！')</script>";
		  }
	   }
	      $this->display();
    }
	
	 public function zhuce(){
	   if(!empty($_POST)){
	          $username1 = mysql_real_escape_string($_POST['username']);
		      $user = D('user');
			  mysql_query("SET NAMES gb2312");
		      $info = mysql_real_escape_string($user -> create());
			  $infoa = $user -> where("username='$username1'") -> find();
		     if($infoa){
		       echo "<script>alert('该用户名已存在！')</script>";
	      	}else{
			   $user->add($info);
			   echo "<script>alert('恭喜您注册成功，快去登陆吧!')</script>";
			}
	   }
     
     if(!empty($_GET)){
     	$name = mysql_real_escape_string($_GET['name']);
     	$user = D('user');
     	$infoa = $user -> where("username='$name'") -> find();
     	if($infoa){
     		echo 1;
     		die;
     	}else{ echo 0;die; }
     }
      $this->display();
    }
	
	 public function index(){
	   $goods = D('goods');
	   $info = $goods -> order('id desc')->limit(10)->select();
	   $this->assign('info',$info);
	   $new = D('new');
	   $info1 = $new -> order('id desc')->limit(5)->select();
	   $this->assign('info1',$info1);
       $this->display();
    }
	
	 public function gouwu(){
           $id = mysql_real_escape_string($_GET['id']);
	       $goods=D('goods');
	       //mysql_query("SET NAMES gb2312");
	       $info = $goods -> where("id='$id'") -> select();
	       if($info){
	       $this->assign('info',$info);
	       //var_dump($info);
           $this->display();
       }else{
       	   $info = $goods -> where("id='1'") -> select();
       	   $this->assign('info',$info);
           $this->display();
       }
       
    }

	 public function goodsshow(){
	  $goods=D('goods');
	  mysql_query("SET NAMES gb2312");
	  $info = $goods -> select();
	  $this->assign('info',$info);
      $this->display();
     }

     public function newshow(){
      $id = mysql_real_escape_string($_GET['id']);
	  $new=D('new');
	  //mysql_query("SET NAMES gb2312");
	  $info = $new -> where("id='$id'") -> find();
	  if($info){
	        $this->assign('info',$info);
            $this->display();
        }else{
           $info = $new -> where("id='1'") -> find();
           $this->assign('info',$info);
           $this->display();
        }
     }

	  public function sousuo(){
	  if(isset($_POST['okok']))
	  {
	      $value = mysql_real_escape_string($_POST['sou']);
	      //var_dump($value);
		  $goods=D('goods');
		  mysql_query("SET NAMES gb2312");
		  $info = $goods -> where("goods_desc like '%$value%'") -> select();
		  if($info){
		  $this->assign('info',$info);
		  }else{
		    $this->show('没有搜索到以此相关的商品！');
		  }
		  $this->display();
	  }
     }
     public function buy(){
     	if(isset($_POST['gouwu']))
     	{
     		$id = mysql_real_escape_string($_POST['id']);
     		$goods=D('goods');
	        $info = $goods -> where("id='$id'") -> select();
	        $this->assign('info',$info);
     		//var_dump($id);
     		$this->display();
     	}
     }
      public function buyok(){
     	if(isset($_POST['buyok']))
     	{
     		if(isset($_SESSION['user']))
     		{
     		$data['id'] = $_POST['id'];
     		$data['username'] =  $_SESSION['user']; 
     		$data['goods_name'] = $_POST['goods_name'];
     		$data['sm_logo'] = $_POST['sm_logo'];
     		$data['goods_desc'] = $_POST['goods_desc'];
     		$data['goods_count'] = $_POST['price'];
     		$data['pricecount'] = $_POST['goods_count'];
     		$data['price'] = $_POST['pricecount'];
     		$userlist=D('userlist');
            $info = $userlist->add($data);
            if($info!=0)
            {
            	$this->success('购买成功,正在为您跳转您的订单页面......','usershow2',5);
            }
           }else{$this->error('您尚未登录,正在为您跳转登录页面......','denglu',5);}
     	}
     }
     public function usershow1(){
     	    if(isset($_SESSION['user']))
     		{
     		  $username =  $_SESSION['user']; 
     		  $user=D('user');
	          $info = $user -> where("username='$username'") -> select();
	          $this->assign('info',$info);
     		  $this->display();
     	   }else{$this->error('您尚未登录,正在为您跳转登录页面......','denglu',5);}
     	   if(isset($_POST['usershow1']))
     	   {
     	   	  $user=D('user');
     	   	  $username = $_POST['username'];
     	   	  $data['password'] = $_POST['password'];
     	   	  $result=$user->where("username='$username'")->save($data);
     	   	  if($result){
		      echo "<script>alert('修改成功！下次登录不要忘记密码哦...')</script>";
		      }
     	   }
     }
     public function usershow2(){
     	    if(isset($_SESSION['user']))
     		{
               $username =  $_SESSION['user'];
               $userlist=D('userlist');
	           $info = $userlist -> where("username='$username'") -> select();
	           $this->assign('info',$info);
     		   $this->display();
     		}
     }
	public function verifyimg(){
	   $config = array(
	               'fontSize'    =>    15,    // 验证码字体大小  
	               'length'      =>    4,     // 验证码位数
				   'imageH'    =>  30,               // 验证码图片高度
                   'imageW'    =>  100,               // 验证码图片宽度
                   'fontttf'   =>  '4.ttf',              // 验证码字体，不设置随机获取 
				   );
	   $img = new \Think\Verify($config);
	   $img -> entry();
	}
	public function logout(){
	   unset($_SESSION['user']);
	   $this->redirect('denglu');
	}
}

?>