<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>记录id</td>
		<td>角色名称</td>
		<td>权限ids</td>
		<td>权限ac</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['role_id']); ?></td>
		<td><?php echo ($v['role_name']); ?></td>
		<td><?php echo ($v['role_auth_ids']); ?></td>
		<td><?php echo ($v['role_auth_ac']); ?></td>
		<td>
		<a href="/foodshop/index.php/Admin/Role/distribute.html?role_id=<?php echo ($v[role_id]); ?>">分配权限</a>
		<a href="<?php echo U('edit?id='.$v['id'].'&p='.I('get.p',1)); ?>" >修改</a>
		<a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['id'].'&p='.I('get.p',1)); ?>" >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>