<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<title></title>
</head>
<body>
<form method="post" action="/foodshop/index.php/Admin/Order/edit/id/10.html" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $info['orderid']; ?>">
	购买数量：<input type="text" name="goods_count" value="<?php echo $info['goods_count']; ?>" /><br />
	总金额：<input type="text" name="pricecount" value="<?php echo $info['pricecount']; ?>" /><br />
	<input type="submit" value="提交">
</form>
</body>
</html>