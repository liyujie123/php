<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<br />
<div style="text-align:right"><a href="/foodshop/index.php/Admin/Auth/tianjia" style="font-size:20px;">添加权限</a></div>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>序号</td>
		<td>权限名称</td>
		<td>父id</td>
		<td>控制器</td>
		<td>操作方法</td>
		<td>全路径</td>
		<td>等级</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['auth_id']); ?></td>
		<td><?php echo (str_repeat($ge,$v['auth_level'])); echo ($v['auth_name']); ?></td>
		<td><?php echo ($v['auth_pid']); ?></td>
		<td><?php echo ($v['auth_c']); ?></td>
		<td><?php echo ($v['auth_a']); ?></td>
		<td><?php echo ($v['auth_path']); ?></td>
		<td><?php echo ($v['auth_level']); ?></td>
		<td>
		<a href="<?php echo U('edit?id='.$v['id'].'&p='.I('get.p',1)); ?>" >修改</a>
		<a onClick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['auth_id']); ?>" >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>