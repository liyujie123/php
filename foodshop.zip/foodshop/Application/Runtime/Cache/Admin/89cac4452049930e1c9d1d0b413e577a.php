<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<div>
    <span>当前的位置是：角色管理-》分配权限信息【<?php echo ($role_info['role_name']); ?>】</span>
</div>
<br>
    <div>
    <form action='/foodshop/index.php/Admin/Role/distribute.html?role_id=2' method='post'>
    	<table cellspacing="1">
    	<?php if(is_array($auth_infoA)): $i = 0; $__LIST__ = $auth_infoA;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
    			<td width="25%" style="border-bottom:2px solid gray;">
                <input type="checkbox" name="auth_id[]" value="<?php echo ($v['auth_id']); ?>" <?php if(in_array($v['auth_id'],$authidsarr)): ?>checked='checked'<?php endif; ?> /><?php echo ($v['auth_name']); ?></td>
    			<td width="65%" style="border-bottom:2px solid gray;">
    			<?php if(is_array($auth_infoB)): $i = 0; $__LIST__ = $auth_infoB;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i; if($vv['auth_pid'] == $v['auth_id']): ?><div style="width:200px;float:left;">
    			    <input type="checkbox" name="auth_id[]" value="<?php echo ($vv['auth_id']); ?>" <?php if(in_array($vv['auth_id'],$authidsarr)): ?>checked='checked'<?php endif; ?> /><?php echo ($vv['auth_name']); ?>
    			  </div><?php endif; endforeach; endif; else: echo "" ;endif; ?>
    			</td>
    		</tr><?php endforeach; endif; else: echo "" ;endif; ?>
    	</table>
    	 <input type="submit" value="分配权限" />
    	</form>
    </div>
</body>
</html>