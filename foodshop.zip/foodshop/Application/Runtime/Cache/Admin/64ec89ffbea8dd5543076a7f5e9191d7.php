<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>序号</td>
		<td>用户名称</td>
		<td>商品名称</td>
		<td>商品描述</td>
		<td>购买数量</td>
		<td>价格</td>
		<td>商品图片</td>
		<td>总金额</td> 
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['orderid']); ?></td>
		<td><?php echo ($v['username']); ?></td>
		<td><?php echo ($v['goods_name']); ?></td>
		<td><?php echo ($v['goods_desc']); ?></td>
		<td><?php echo ($v['goods_count']); ?></td>
		<td><?php echo ($v['price']); ?></td>
		<td><img src="/foodshop/Uploads/<?php echo ($v['sm_logo']); ?>"></td>
		<td><?php echo ($v['pricecount']); ?></td>
		<td>
		<a href="<?php echo U('edit?id='.$v['orderid']); ?>" >修改</a>
		<a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['orderid']); ?>"  >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>