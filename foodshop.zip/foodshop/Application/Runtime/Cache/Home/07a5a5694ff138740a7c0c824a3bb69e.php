<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/foodshop/Public/Home/css/buy.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/foodshop/Public/Home/js/buy.js"></script>
<title>订单页面</title>
</head>
<body>
<div id="Layer0" align="center">
<div id="Layer1">
     <div id="Layer2">
	    <a href="index"><div id="Layer2-1">返回首页</div></a>
		<div id="Layer2-1-1">订单信息</div>
		<div id="Layer2-2">
		   <div id="Layer2-2-1"><img src="/foodshop/Uploads/<?php echo ($info[0][sm_logo]); ?>" width="60px" height="60px" /></div>
		   <div id="Layer2-2-2"><?php echo ($info[0][goods_desc]); ?></div>
		   <div id="Layer2-2-3"><span id="price"><?php echo ($info[0][price]); ?></span></div>
		   <div id="Layer2-2-4">
		   <div id="Layer2-2-4-1" onclick="f1()" id="str1"></div>
		   <div id="Layer2-2-4-2"><span id="str2">1</span></div>
		   <div id="Layer2-2-4-3" onclick="f2()" id="str3"></div>
		   </div>
		   <div id="Layer2-2-5"><span id="count"><?php echo ($info[0][price]); ?></span></div>
		</div>
		<form action="/foodshop/index.php/home/index/buyok" method="post">
		<input type="hidden" value="<?php echo ($info[0][id]); ?>" name="id" />
		<input type="hidden" value="<?php echo ($info[0][goods_name]); ?>" name="goods_name" />
		<input type="hidden" value="<?php echo ($info[0][sm_logo]); ?>" name="sm_logo" />
		<input type="hidden" value="<?php echo ($info[0][goods_desc]); ?>" name="goods_desc" />
		<input type="hidden" value="<?php echo ($info[0][price]); ?>" name="price" />
		<input type="hidden" value="1" name="goods_count" id="goodscount" />
		<input type="hidden" value="<?php echo ($info[0][price]); ?>" name="pricecount" id="pricecount" />
		<div id="Layer2-3"><input type="submit" name="buyok" class="button1" value="确定购买"></div>
		</form>
	 </div>
  </div>
</div>
</body>
</html>