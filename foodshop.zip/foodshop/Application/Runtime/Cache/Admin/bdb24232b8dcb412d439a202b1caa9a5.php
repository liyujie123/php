<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/foodshop/Public/Admin/Css/top.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="Layer0" align="left">
   <div id="Layer1">
         <div id="Layer1-1">
		    <div id="Layer1-1-1">ecshop</div>
			<div id="Layer1-1-2">
			  <div id="Layer1-1-2-1">
			     <div id="Layer1-1-2-1-1"><a href="/foodshop/index.php" target="_blank">查看网站</a></div>
				 <div id="Layer1-1-2-1-2">个人设置</div>
				 <div id="Layer1-1-2-1-3">刷新</div>
			  </div>
			  <div id="Layer1-1-2-2">
			      <div id="Layer1-1-2-2-1">清除缓存</div>
				  <div id="Layer1-1-2-2-2"><a onClick="return confirm('确定要退出吗？');" href="/foodshop/index.php/Admin/Index/exitlogin">退出</a></div>
			  </div>
			</div>
		 </div> 
         <div id="Layer1-2">
		  <div id="Layer1-2-1">起始页</div>
		  <div id="Layer1-2-2"><a href="<?php echo U('goods/lst'); ?>" target="main-frame">商品列表</a></div>
		  <div id="Layer1-2-3"><a href="<?php echo U('order/showlist'); ?>" target="main-frame">订单列表</div>
		  <div id="Layer1-2-4"><a href="<?php echo U('user/showlist'); ?>" target="main-frame">用户评论</div>
		  <div id="Layer1-2-5"><a href="<?php echo U('user/showlist'); ?>" target="main-frame">会员列表</div>
		 </div> 
   </div>
 </div>
</body>
</html>