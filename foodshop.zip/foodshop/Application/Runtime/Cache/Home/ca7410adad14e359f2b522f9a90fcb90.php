<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/foodshop/Public/Home/css/goodsshow.css" rel="stylesheet" type="text/css" />
<title>商品展示</title>
</head>
<body>
<div id="Layer0" align="center">
<div id="Layer1">
  <div id="Layer3"><a href="index.html">返回首页</a></div>
     <?php if(is_array($info)): foreach($info as $key=>$v): ?><div id="Layer2">
         <div id="Layer2a"><img src="/foodshop/Uploads/<?php echo ($v["logo"]); ?>" width="240px" height="200px"></div>
		   <div id="Layer2b">￥<?php echo ($v["price"]); ?></div>
		   <div id="Layer2c">数量：<?php echo ($v["goods_count"]); ?></div>
	       <div id="Layer2d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($v["id"]); ?>" class="goods" target="_blank"><?php echo ($v["goods_desc"]); ?></a></div>
     </div><?php endforeach; endif; ?>
  </div>
</div>
</body>
</html>