<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>购物中心</title>
<script type="text/javascript" src="/foodshop/Public/Home/js/gouwu.js"></script>
<link href="/foodshop/Public/Home/css/gouwu.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="Layer0" align="center">
<div id="Layer1">
  <div id="Layer2">
    <div id="Layer3">
	  <div id="Layer4A"><a href="/foodshop/index.php" target="_blank">商场首页</a></div>
      <div id="Layer4">您好，<?php echo (session('user')); ?></div>
      <div id="Layer5"><a href="/foodshop/index.php/home/index/zhuce.html" target="_blank">免费注册</a></div>
      <div id="Layer6"><a href="/foodshop/index.php/home/index/usershow1.html" target="_blank">个人中心</a></div>
      <div id="Layer7"><a href="#">关注食窝</a></div>
      <div id="Layer8"><a href="#">客户服务</a></div>
      <div id="Layer9"><a href="#">网站导航</a></div>
    </div>
  </div>
  <div id="Layer10">
      <div id="Layer11"><img src="/foodshop/Public/Home/pic/dian.png" width="180" height="30"></div>
	  <div id="Layer12">宇杰美食店</div>
	  <form action="/foodshop/index.php/home/index/sousuo" method="post">
	  <div id="Layer13"><input type="text" class="sousuo2" name="sou" border="2px"><input type="submit" name="okok" class="sousuo3" border="2px" value="搜食窝">&nbsp;<input type="submit" name="okok" class="sousuo4" border="2px" value="搜本店"></div>
	  </form>
  </div>
  <div id="Layer14">
          <div id="Layer15"></div>
          <div id="Layer16"><img src="/foodshop/Public/Home/pic/dian1.png" width="800" height="100"></div>
  </div>
  <div id="Layer17">
          <div id="Layer18"><a href="#" class="a3">所有分类</a></div>
		  <div id="Layer19"><a href="#" class="a3">首页</a></div>
		  <div id="Layer20"><a href="#" class="a3">店铺活动</a></div>
		  <div id="Layer21"><a href="#" class="a3">俄罗斯进口拉米</a></div>
		  <div id="Layer22"><a href="#" class="a3">俄罗斯进口食油</a></div>
		  <div id="Layer23"><a href="#" class="a3">俄罗斯进口饼干</a></div>
		  <div id="Layer24"><a href="#" class="a3">俄罗斯进口饮品</a></div>
		  <div id="Layer25"><a href="#" class="a3">俄罗斯进口糖果</a></div>
  </div>
  <div id="Layer26">
     <div id="Layer27">
	      <div id="Layer30"><img id="tu5" src="/foodshop/Uploads/<?php echo ($info[0][logo]); ?>" width="400" height="330"></div>
	      <div id="Layer31">
		     <div id="Layer31a"><img id="tu1" src="/foodshop/Uploads/<?php echo ($info[0][logo]); ?>" width="100" height="100" onmouseover="tua()"></div>
			 <div id="Layer31b"><img id="tu2" src="/foodshop/Public/Home/pic/tu22.jpg" width="100" height="100" onmouseover="tub()"></div>
			 <div id="Layer31c"><img id="tu3" src="/foodshop/Public/Home/pic/tu33.jpg" width="100" height="100" onmouseover="tuc()"></div>
			 <div id="Layer31d"><img id="tu4" src="/foodshop/Public/Home/pic/tu44.jpg" width="100" height="100" onmouseover="tud()"></div>
		  </div>
	 </div>
	 <div id="Layer28">
	      <div id="Layer32"><?php echo ($info[0][goods_desc]); ?></div>
	      <div id="Layer33">
		     <div id="Layer33a">￥<?php echo ($info[0][price]); ?></div>
			 <div id="Layer33aa"></div>
			 <div id="Layer33b">￥<?php echo ($info[0][price]); ?></div>
		  </div>
		  <form action="/foodshop/index.php/home/index/buy" method="post">
		  <input type="hidden" value="<?php echo ($info[0][id]); ?>" name="id" />
		  <div id="Layer34"><input type="submit" name="gouwu" class="button1" value="立即购买"></div>
	      <div id="Layer35"><input type="submit" class="button2" value="加入购物车" name="gouwu"></div>
	      </form>
	 </div>
	 <div id="Layer29">
	      <div id="Layer36"><img src="/foodshop/Public/Home/pic/dian4.png" width="180" height="250"></div>
	      <div id="Layer37"></div>
	 </div>
  </div>
  <div id="Layer38">
	      <div id="Layer38a"><a href="#">关于我们</a></div>
		  <div id="Layer38b"><a href="#">友情链接</a></div>
		  <div id="Layer38c"><a href="#">人才招聘</a></div>
		  <div id="Layer38d"><a href="#">合作团队</a></div>
		  <div id="Layer38e"><a href="#">技术中心</a></div>
		  <div id="Layer38f"><a href="#">加盟好友</a></div>
		  <div id="Layer38g"><a href="#">联系方式</a></div>
		  <div id="Layer38h">开发者：李宇杰&nbsp;&nbsp;&nbsp;&nbsp;620022430@qq.com&nbsp;&nbsp;&nbsp;&nbsp;版权所有</div>
	   </div>
   </div>
</div>
</body>
</html>