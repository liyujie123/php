<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/foodshop/Public/Home/css/newshow.css" rel="stylesheet" type="text/css">
<title>公告展示</title>
</head>
<body>
<div id="Layer0" align="center">
<div id="Layer1">
  <div id="h"></div>
     <div id="Layer2">
	    <a href="index"><div id="Layer2-1">返回首页</div></a>
		<div id="Layer2-2">
		  <?php if(is_array($info)): foreach($info as $key=>$n): ?><div id="Layer2-2-1"><?php echo ($info[title]); ?></div>
		  <div id="Layer2-2-2"></div>
		  <div id="Layer2-2-3"><?php echo ($info[content]); ?></div><?php endforeach; endif; ?>
		</div>
	 </div>
  </div>
</div>
</body>
</html>