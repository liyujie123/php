<?php
namespace Admin\Model;
use Think\Model;
class GoodsModel extends Model
{
   //定义表单验证的规则，控制中的create方法时用
  protected $_validate = array(
    array('goods_name','require','商品名称不能为空！',1),
  ); 	

  protected function _before_insert(&$data,$option){
  	//获得当前时间
  	$data['addtime'] = time();
  	//var_dump($data);
    
    //上传LOGO
    $ret = uploadOne('logo','Goods',array(
        array(100,100),
      ));
    if($ret['ok']==1)
    {
      //把图片的路径放到数据库中
      $data['logo'] = $ret['images'][0];
      $data['sm_logo'] = $ret['images'][1];
    }
    else
    {
      $this->error = $ret['error'];
      return fales;
    }

  // if($_FILES['logo']['error']==0){
  // 	 $upload = new \Think\Upload();
  // 	 //$upload->maxSize = 3145728;
  // 	   $upload->maxSize = (int)C('IMG_maxSize') * 1024 * 1024;
  // 	 //$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
  // 	   $upload->exts = C('IMG_exts');
  // 	 //$upload->rootPath = './Uploads/'; // 设置附件上传目录
  //      $upload->rootPath = C('IMG_rootPath');
  // 	   $upload->savePath = 'Goods/'; //图片的二级目录的名称
  // 	 //上传文件
  // 	 $info = $upload->upload();
  // 	 if(!$info){
  // 	 	 $this->error = $upload->getError();
  // 	 	 return fales;
  // 	 }
  // 	 else{
  // 	 	$logoName = $info['logo']['savepath'].$info['logo']['savename'];
  //       //拼出缩略图的文件名
  //        $smLogoName = $info['logo']['savepath'].'thumb_'.$info['logo']['savename'];
  //       //生成缩略图
  //        $image = new \Think\Image(); 
  // 	    //打开要处理的图片
  // 	     $image -> open('./Uploads/'.$logoName);
  // 	     $image -> thumb(150,150) -> save('./Uploads/'.$smLogoName);
  // 	     $data['sm_logo'] = $smLogoName;
  // 	     $data['logo'] = $logoName;
  // 	 }
  // }
 }
  
   protected function _before_update(&$data,$option){
     // if($_FILES['logo']['error']==0){
     //  $upload = new \Think\Upload();
     // //$upload->maxSize = 3145728;
     //   $upload->maxSize = (int)C('IMG_maxSize') * 1024 * 1024;
     // //$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
     //   $upload->exts = C('IMG_exts');
     // //$upload->rootPath = './Uploads/'; // 设置附件上传目录
     //   $upload->rootPath = C('IMG_rootPath');
     //   $upload->savePath = 'Goods/'; //图片的二级目录的名称
     // //上传文件
     // $info = $upload->upload();
     // if(!$info){
     //   $this->error = $upload->getError();
     //   return fales;
     // }
     // else{
     //  $logoName = $info['logo']['savepath'].$info['logo']['savename'];
     //    //拼出缩略图的文件名
     //     $smLogoName = $info['logo']['savepath'].'thumb_'.$info['logo']['savename'];
     //    //生成缩略图
     //     $image = new \Think\Image(); 
     //    //打开要处理的图片
     //     $image -> open('./Uploads/'.$logoName);
     //     $image -> thumb(150,150) -> save('./Uploads/'.$smLogoName);
     //     $data['sm_logo'] = $smLogoName;
     //     $data['logo'] = $logoName;
     
     $ret = uploadOne('logo','Goods',array(
        array(100,100),
      ));
    if($ret['ok']==1)
    {
      //把图片的路径放到数据库中
      $data['logo'] = $ret['images'][0];
      $data['sm_logo'] = $ret['images'][1];
    }
    else
    {
      $this->error = $ret['error'];
      return fales;
    }

        //删除商品的原图片
         //先根据商品的ID取出这件商品的图片的路径
         $logo = $this -> field('logo,sm_logo')->find($option['where']['id']);
        //从配置文件取出图片所在目录
         $rp = C('IMG_rootPath');
        //删除图片
         unlink($rp.$logo['logo']);
         unlink($rp.$logo['sm_logo']);
}

   public function search(){
     /***********搜索********/
     $where = array();
     //商品名称的搜索
     if($goodsName = I('get.goods_name'))
          $where['goods_name'] = array('like',"%$goodsName%");
     //价格的搜索
     $startPrice = I('get.start_price');
     $endPrice = I('get.end_price');
     if($startPrice && $endPrice)
     	$where['price'] = array('between', array($startPrice,$endPrice));
     elseif($startPrice)
     	$where['price'] = array('gt',$startPrice);
     elseif($endPrice)
     	$where['price'] = array('lt',$endPrice);
     //上架的搜索
     $isOnsale = I('get.is_on_sale',-1);
     if($isOnsale != -1)
     	$where['is_on_sale'] = array('eq',$isOnsale);
     //是否删除的搜索
     $isDelete = I('get.is_delete',-1);
     if($isDelete != -1)
     	$where['is_delete'] = array('eq',$isDelete);
     //时间的搜索
     $startAddtime = I('get.start_addtime');
     $endAddtime = I('get.end_addtime');
     if($startAddtime && $endAddtime)
       $where['addtime'] = array('between',array(strtotime("$startAddtime 00:00:01"),strtotime("$endAddtime 23:59:59")));
     elseif($startAddtime)
       $where['addtime'] = array('egt',strtotime("$startAddtime 00:00:01"));
     elseif($endAddtime)
       $where['addtime'] = array('elt',strtotime("$endAddtime 23:59:59"));
     /***********排序********/
     $orderby = 'id';  //默认排序字段
     $orderway = 'asc'; //默认排序方式
     $odby = I('get.odby');
     if($odby && in_array($odby,array('id_asc','id_desc','price_asc','price_desc')))
     {
     	if($odby == 'id_desc')
     		$orderway = 'desc';
     	elseif($odby == 'price_asc')
     		$orderby ='price';
     	elseif($odby == 'price_desc')
     	{
     		$orderby = 'price';
     		$orderway = 'desc';
     	}
     }
   	 /***********翻页********/
   	 //总的记录数
   	 $count = $this->where($where)->count();
   	 //生成翻页对象
   	 $page = new \Think\Page($count,3);
     $page->setConfig('next','下一页');
     $page->setConfig('prev','上一页');
   	 //获取翻页字符串
     $pageString = $page->show();
     //取出当前页的数据
     $data = $this->where($where)->limit($page->firstRow.','.$page->listRows)->order("$orderby $orderway")->select();
     return array(
     	'page' => $pageString,
     	'data' => $data,
     	);

   }

   public function img(){

   	 $image = new \Think\Image();
   	 $image->open('./1.jpg');
   	 // 按照原图的比例生成一个最大为150*150的缩略图并保存为thumb.jpg
   	 $image->thumb(150, 150)->save('./thumb.jpg');
   	 return $image;
   }

    //在控制器中调用delete方法之前会自动调用
   protected function _before_delete($option){
     //先根据商品的ID取出这件商品的图片的路径
     $logo = $this -> field('logo,sm_logo')->find($option['where']['id']);
     //从配置文件取出图片所在目录
     // $rp = C('IMG_rootPath');
     // //删除图片
     // unlink($rp.$logo['logo']);
     // unlink($rp.$logo['sm_logo']);
     deleteImage($logo);
   }

  public function tree($arr,$pid=0,$level=0){
    static $tree = array();
    foreach ($arr as $v) {
      if($v['parent_id']==$pid){
        $v['level'] = $level;
        $tree[] = $v;
        $this->tree($arr,$v['id'],$level+1);
      }
    }
    return $tree;
  }

  //定义一个方法，获得指定节点所有的子孙节点的id
  public function getSubIds($pid){
     $cats=$this->select();
     $cats=$this->tree($cats,$pid);
     $list = array();
     foreach ($cats as $cats) {
       $list[] = $cats['id'];
     }
     return $list;
  }

}