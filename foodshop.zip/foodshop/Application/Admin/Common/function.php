<?php

function uploadOne($imgName,$dirName,$thumb = array())
{
    if($_FILES[$imgName]['error']==0){
  	 $upload = new \Think\Upload();
  	 //$upload->maxSize = 3145728;
  	   $upload->maxSize = (int)C('IMG_maxSize') * 1024 * 1024;
  	 //$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
  	   $upload->exts = C('IMG_exts');
  	 //$upload->rootPath = './Uploads/'; // 设置附件上传目录
       $upload->rootPath = C('IMG_rootPath');
  	   $upload->savePath = $dirName.'/'; //图片的二级目录的名称
  	 //上传文件
  	 $info = $upload->upload();
  	 if(!$info){
         return array(
         	'ok'=>0,
         	'error'=>$upload->getError(),
         	);
  	 }
  	 else{
  	 	$ret['ok']=1;
  	 	$ret['images'][0]=$logoName = $info[$imgName]['savepath'].$info[$imgName]['savename'];
  	 	//判断是否生成缩略图
  	 	if($thumb)
  	 	{
  	 	 $image = new \Think\Image(); 
  	 	//拼出每张缩略图的文件名
  	 	foreach($thumb as $k => $v)
  	 	{
         $ret['images'][$k+1] = $info[$imgName]['savepath'].'thumb_'.$k.'_'.$info[$imgName]['savename'];
         
         $image -> open('./Uploads/'.$logoName);
  	     $image -> thumb($v[0],$v[1]) -> save('./Uploads/'.$ret['images'][$k+1]);
  	 	}
  	  }
  	  return $ret;
  	 }
  }
}