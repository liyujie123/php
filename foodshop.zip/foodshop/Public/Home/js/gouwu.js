// JavaScript Document

     function tua(){
	    var img =  document.getElementById("tu5");
		var img2 =  document.getElementById("tu1").src;
	    img.setAttribute("src",img2);
	 }
	 function tub(){
	    var img =  document.getElementById("tu5");
	    img.setAttribute("src","http://localhost/foodshop/Public/Home/pic/tu22.jpg");
	 }
	 function tuc(){
	    var img =  document.getElementById("tu5");
	    img.setAttribute("src","http://localhost/foodshop/Public/Home/pic/tu33.jpg");
	 }
	 function tud(){
	    var img =  document.getElementById("tu5");
	    img.setAttribute("src","http://localhost/foodshop/Public/Home/pic/tu44.jpg");
	 }