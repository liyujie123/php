<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="/foodshop/Public/Admin/Css/menu.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="/foodshop/Public/Admin/Js/jquery.js"></script>
</head>
<body>
   <div id="Layer1">
      <div id="Layer1-1"><b>菜单</b></div>
	  <div id="Layer1-2">
	    <div id="Layer1-2-1">
		      <ul id="o">
		      <?php if(is_array($auth_infoA)): $i = 0; $__LIST__ = $auth_infoA;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li><?php echo ($v['auth_name']); ?></li>
			     <div id="div">
				  <ul id="oo">
				  <?php if(is_array($auth_infoB)): $i = 0; $__LIST__ = $auth_infoB;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i; if($vv['auth_pid'] == $v['auth_id']): ?><li><a href="/foodshop/index.php/Admin/<?php echo ($vv['auth_c']); ?>/<?php echo ($vv['auth_a']); ?>" target="main-frame"><?php echo ($vv['auth_name']); ?></a></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				  </ul><?php endforeach; endif; else: echo "" ;endif; ?>
				 </div>
			  </ul>
		</div>
	  </div>
   </div>
</body>
</html>
<script type="text/javascript">
   // $(function(){
   // 	   $('#o > li').css('background-color','red');
   // });
    
    $(function(){
    	$('#o > li').click(function(){
    		if($('#div ul').is(":visible")){
    			$('#div ul').hide();
    		}else{
    			$('#div ul').show();
    		}
    	});

    });
    
  //   var $category=$("#o li:gt(2)")
	 // $category.hide();
	 // var $toggleBtn=$("div.showmore>a")
	 // $toggleBtn.click(function(){
	 //   if($category.is(":visible"))
	 //   {
	 //      $category.hide();
		//   $(this).find("span").text("显示全部品牌");
		//   $('ul li').filter(":contains('佳能'),:contains('尼康'),:contains('偶林巴斯')")
		//           .addClass("promoted");
		// }
		// else
		// {
		//    $category.show();
		//    $(this).find("span").text("精简显示品牌");
		//    $('ul li').filter(":contains('佳能'),:contains('尼康'),:contains('偶林巴斯')")
		//           .addClass("promoted");
		// }
		// return false;
	 // });


</script>