<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<script type="text/javascript" src="/foodshop/Public/jQuery_calendar/js/jquery.js"></script>
<title></title>
</head>
<body>
<table>
<form method="post" action="/foodshop/index.php/Admin/Manager/tianjia">
    <input type="hidden" name="mg_id" value="" />
	<tr><td>管理员名称：</td><td><input type="text" name="mg_name" /></td></tr>
	<tr><td>管理员密码：</td><td><input type="text" name="mg_pwd" /></td></tr>
  <tr><td>角色id：</td><td><select name="mg_role_id">
           <option value="0">-请选择-</option>
           <?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['role_id']); ?>"><?php echo ($v['role_name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?> 
  </select></td></tr>
    <input type="hidden" name="mg_time" value="">
	<tr><td><input type="submit" value="添加"></td>
  </form>
</table>
</body>
</html>