<?php
return array(
	'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  'shop',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  '',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'shop_',    // 数据库表前缀
    /********图片相关的配置*********/
    'IMG_maxSize'    =>  '3M',
    'IMG_exts'       =>  array('jpg','gif','png','jpeg'),
    'IMG_rootPath'   =>  './Uploads/',
    /**********MD5时用来复杂化的********/
    MD5_KEY => 'lyjlyj@###lyj',   
   /**********显示跟踪信息********/
    'SHOW_PAGE_TRACE' => true,  
);