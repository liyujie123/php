<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {

	public function __construct(){
		//验证登陆
		if(!session('admin_id'))
			redirect(U('Admin/Manager/login'));
		//先调用父类的构造函数
		    parent::__construct();
		//实现访问权限控制器过滤功能(防止翻墙访问)
		//1.获得当前请求的controller和action
		$nowac = CONTROLLER_NAME."-".ACTION_NAME;
		//2.获得当前用户对应的角色权限
		$manager_info=D('Manager')->find(session('admin_id')); 
		$role_id=$manager_info['mg_role_id'];
		$role_info=D('Role')->find($role_id);
		$auth_ac=$role_info['role_auth_ac'];
        

        //1.判断用户当前请求的controller和action是否在其权限列表出现
        //2.不要限制admin用户
        //3.允许开放一些不加限制的权限
        $allowac = "Manager-login,Manager-chkcode,Index-index,Index-top,Index-menu,Index-main";
        
        $adminname = session('admin_user');
        if(strrpos($auth_ac,$nowac)===false && $adminname!=='admin' && strrpos($allowac,$nowac)===false){
        	exit('没有权限访问');
        }
	}

	public function index(){
		$this -> display();
	}
	public function menu(){
		//根据用户的角色显示对应的权限
		//1.根据用户的session信息获得其角色id
		$manager_info = D('Manager')->find(session('admin_id'));
		$role_id = $manager_info['mg_role_id'];
		//2.根据$role_id获得权限ids
		$role_info = D('Role')->find($role_id);
		$auth_ids = $role_info['role_auth_ids'];
        //3.根据auth_ids获得权限的详情
        //开放admin绝对权限
        if(session('admin_user')==='admin'){
        $auth_infoA = D('Auth')->where("auth_level=0")->select();
        $auth_infoB = D('Auth')->where("auth_level=1")->select();
        }else{
        $auth_infoA = D('Auth')->where("auth_level=0 and auth_id in ($auth_ids)")->select();
        $auth_infoB = D('Auth')->where("auth_level=1 and auth_id in ($auth_ids)")->select();
        }
        $this->assign('auth_infoA',$auth_infoA);
        $this->assign('auth_infoB',$auth_infoB);
		$this -> display();
	}
	public function top(){
		$this -> display();
	}
	public function main(){
		$this -> display();
	}

	public function setPageBtn($title,$btnName,$btnLink)
	{
		$this->assign('_page_title',$title);
        $this->assign('_page_btn_name',$btnName);
        $this->assign('_page_btn_link',$btnLink);
	}
	
	public function exitlogin(){
	    session(null); 
		echo "<script>parent.location.href='manager/login';</script>";
	}
}