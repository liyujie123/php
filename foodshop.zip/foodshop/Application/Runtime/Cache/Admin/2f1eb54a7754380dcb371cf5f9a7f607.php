<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<br />
<div style="text-align:right"><a href="/foodshop/index.php/Admin/Manager/tianjia" style="font-size:20px;">添加管理员</a></div>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>序号</td>
		<td>管理员名称</td>
		<td>管理密码</td>
		<td>创建时间</td>
		<td>角色id</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['mg_id']); ?></td>
		<td><?php echo ($v['mg_name']); ?></td>
		<td><?php echo ($v['mg_pwd']); ?></td>
		<td><?php echo ($v['mg_time']); ?></td>
		<td><?php echo ($v['mg_role_id']); ?></td>
		<td>
		<a href="#" >修改</a>
		<a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['mg_id']); ?>"  >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>