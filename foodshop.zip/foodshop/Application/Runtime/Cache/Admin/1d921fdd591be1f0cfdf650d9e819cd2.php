<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<table width="100%" border="1px">
	<tr>
		<td>id</td>
		<td>商品名称</td>
		<td>父级id</td>
		<td>描述</td>
		<td>库存</td>
		<td>操作</td>
	</tr>
	<?php foreach ($data as $k => $v): ?>
	<tr>
		<td><?php echo ($v["id"]); ?></td>
		<td><?php echo str_repeat("--/", $v['level']); echo ($v["goods_name"]); ?></td>
		<td><?php echo ($v["parent_id"]); ?></td>
		<td><?php echo ($v["goods_desc"]); ?></td>
		<td><?php echo ($v["goods_count"]); ?></td>
		<td> <a href="<?php echo U('edit?id='.$v['id'].'&p='.I('get.p',1)); ?>" >修改</a>
		    <a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['id'].'&p='.I('get.p',1)); ?>" >删除</a>
		</td>
	</tr>
   <?php endforeach; ?>
</table>
</body>
</html>