<?php
namespace Admin\Controller;
use Think\Controller;
class NewController extends Controller {

    public function showlist(){
      $model = D('New');
      //获取带翻页的数据
      $info = $model->select();
      $this->assign('info',$info);
      $this->display();
  }

	public function delete(){
       $model = D('New');
      //$model -> delete(I('get.id'));
       $id=I('get.id'); 
      //$arr = $model -> getSubIds($id);
      $model -> delete($id);
      $this -> success('删除成功',U('showlist'));
  }

  public function edit(){
    //处理表单
    if(IS_POST){
      $model = D('New');
      if($model->create(I('post.'),2)){
        if(FALSE !== $model->save()){
          //提示信息
          $this->success('操作成功',U('showlist'));
          exit;
        }
      }
      //如果失败显示错误信息
      $this -> error($model->getError());
    }
    //接收商品的ID
    $id = I('get.id');
    //先从数据库中取出要修改的记录的信息
    $model = M('New');
    $info = $model->find($id);
    $this -> assign('info',$info);
    //显示修改的表单
    $this -> display();
  }

  public function add(){ 
      $model = D('New');
      if(IS_POST){
          if($model->create()){
            if($model->add()) 
            {
              $this->success('操作成功','showlist');
              exit;
            }
          }
         $error = $model->getError();
         $this -> error($error);
       }
       $this->display();
    }

}