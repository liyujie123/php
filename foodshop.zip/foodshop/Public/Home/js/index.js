// JavaScript Document

$(function(){
      $("#Layer23,#Layer24,#Layer25,#Layer26,#Layer27,#Layer28,#Layer29").mouseover(function(){
    	 $(this).css({"background-color":"#FFFFFF","color":"#FF0000"});
    	 $('a.goodslist:link').css("color","#FF0000");
		 $("#Layer30a").css("display","block");
      });

    //  $('a.goodslist:link').mouseover(function(){$('a.goodslist:link').css("color","#FF0000")});
    //  $('a.goodslist:link').mouseout(function(){$('a.goodslist:link').css("color","#FFFFFF")});

	  $("#Layer23,#Layer24,#Layer25,#Layer26,#Layer27,#Layer28,#Layer29").mouseout(function(){
    	 $(this).css({"background-color":"#FF0000","color":"#FFFFFF"});
    	 $('a.goodslist:link').css("color","#FFFFFF");
		 $("#Layer30a").css("display","none");
     });
	  
	 $("#Layer35,#Layer36,#Layer37,#Layer38,#Layer39,#Layer40,#Layer41,#Layer42,#Layer43,#Layer44").mouseover(function(){
    	 $(this).css('border','1px solid red');
      });
	 
	 $("#Layer35,#Layer36,#Layer37,#Layer38,#Layer39,#Layer40,#Layer41,#Layer42,#Layer43,#Layer44").mouseout(function(){
    	 $(this).css("border-color","#cccccc");
      });

     $("#Layer30,#Layer30A,#Layer30B").mouseover(function(){
	 	  $("#Layer30A,#Layer30B").css("display","block");
	  });
	 $("#Layer30,#Layer30A,#Layer30B").mouseout(function(){
	 	  $("#Layer30A,#Layer30B").css("display","none");
	  });

});

     function imgA(){
	        var img =  document.getElementById("img2");
	        var name = document.getElementById("img2").src;
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu1.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu4.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu2.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu1.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu3.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu2.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu4.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu3.jpg");
		   }
	  }
	  function imgB(){
	        var img =  document.getElementById("img2");
	        var name = document.getElementById("img2").src;
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu1.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu2.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu2.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu3.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu3.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu4.jpg");
		   }
		    if(name=="http://localhost/foodshop/Public/Home/pic/zhu4.jpg"){
			   img.setAttribute("src","/foodshop/Public/Home/pic/zhu1.jpg");
		   }
	 }
      	 
	 //window.onload = function(){
		//showtime函数需要每隔1s就执行一次
		//setInterval全局变量处理，时间毫秒
		//mytime = setInterval("imgA()",3000);
	//}
	 var mytime = "";
	function start(){
		  mytime = setInterval("imgA()",4000);
		}
	function cancel(){
			clearInterval(mytime);
		}
		