<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="/Public/jQuery_calendar/js/jquery.js"></script>
<title>无标题文档</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:100%;
	height:100%;
	z-index:1;
	background-color:#006699;
}
#Layer2 {
	position:relative;
	top:20%;
	width:400px;
	height:200px;
	z-index:2;
}
#Layer2-1 {
	position:relative;
	width:auto;
	height:auto;
	z-index:3;
	color:#FFFFFF
}
.input{
     width:150px;
}
-->
</style>
</head>
<body>
<div id="Layer1" align="center">
    <div id="Layer2" align="center">
	 <div id="Layer2-1">
	 <form method="post" action="/index.php/Admin/Admin/login.html" name="main_form1">
	 <table>
	  <tr><td>管理员姓名：</td><td><input class="input" type="text" name="username"></td></tr>
	  <tr><td>管理员密码：</td><td><input class="input" type="password" name="password"/></td></tr>
	  <tr><td>验证码：</td><td><input class="input" type="text" name="chkcode"></td><td><img width="100px" height="30px" onclick=" this.src='<?php echo U('chkcode'); ?>#'+Math.random(); " src="<?php echo U('chkcode'); ?>"></td></tr>
	  <tr><td colspan="2" align="center"><input type="submit" name="ok" value="进入管理中心"></td><td></td></tr>
	 </table>
	 </form>
	 </div>
	</div>
</div>
</div>
</body>
</html>
<!--<script type="text/javascript">
	//为表单绑定AJAX提交事件
    $("form[name=main_form1]").submit(function(){
    	//使用AJAX来提交
    	$.ajax({
           type:"POST",
           url:"/index.php/Admin/Admin/login.html",
           data:$(this).serialize,  //收集表单中的数据
           dataType:"json",         //标记服务器返回的是JSON数据
           success:function(data){   //ajax执行完之后的回调函数
              //判断添加是否成功
              if(data.status == 1){
              	alert(data.info);
              	location.href = data.url;              
           }
           else{
           	    alert(data.info);
           }
       }
    	});
    //阻止表单提交
    return false;
    });
</script>