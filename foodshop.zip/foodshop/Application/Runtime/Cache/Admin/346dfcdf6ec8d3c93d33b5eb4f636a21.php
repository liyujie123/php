<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<script type="text/javascript" src="/foodshop/Public/jQuery_calendar/js/jquery.js"></script>
<title></title>
</head>
<body>
<form name="main_form" method="post" action="/foodshop/index.php/Admin/Goods/add.html" enctype="multipart/form-data">
	商品名称：<input type="text" name="goods_name" /><br />
  商品分类：<select name="parent_id">
              <option value="0">-请选择-</option>
                 <?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['id']); ?>"><?php echo ($v['goods_name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?> 
           </select><br />
	商品价格：<input type="text" name="price" /><br />
  商品库存：<input type="text" name="goods_count" /><br />
	商品logo：<input type="file" name="logo" /><br />
	商品描述：<br /><textarea name="goods_desc" id="goods_desc" style="width:600px;height:300px"></textarea><br />
	是否上架：
	<input type="radio" name="is_on_sale" value="1" checked="checked" />上架
	<input type="radio" name="is_on_sale" value="0" />下架
	<br />
	<input type="submit" value="提交">
</form>
</body>
</html>
<!-- <script type="text/javascript">
	//为表单绑定AJAX提交事件
    $("form[name=main_form]").submit(function(){
    	//使用AJAX来提交
    	$.ajax({
           type:"POST",
           url:"/foodshop/index.php/Admin/Goods/add.html",
           data:$(this).serialize,  //收集表单中的数据
           dataType:"json",         //标记服务器返回的是JSON数据
           success:function(data){   //ajax执行完之后的回调函数
              //判断添加是否成功
              if(data.status == 1){
              	alert(data.info);
              	location.href = data.url;              
           }
           else{
           	    alert(data.info);
           }
       }
    	});
    //阻止表单提交
    return false;
    });
</script> -->