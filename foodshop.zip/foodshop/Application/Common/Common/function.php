<?php
 function showImage($url)
  {
      $url = '/foodshop/Uploads/'.$url;
      echo "<img src='$url' />";
  }

 function deleteImage($images)
 {  
 	//先取出图片所在的目录
 	$rp = C('IMG_rootPath');
 	foreach ($images as $v) {
 	  	 unlink($rp.$v);
 	}
 }