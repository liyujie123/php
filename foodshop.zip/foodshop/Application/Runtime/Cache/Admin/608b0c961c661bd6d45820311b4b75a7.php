<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<title></title>
</head>
<body>
<form method="post" action="/foodshop/index.php/Admin/Goods/edit/id/14/p/3.html" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
	商品名称：<input type="text" name="goods_name" value="<?php echo $info['goods_name']; ?>" /><br />
	商品分类：<select name="parent_id">
              <option value="<?php echo $info['parent_id']; ?>"> <?php echo $infoA['goods_name']; ?> </option>
                 <?php if(is_array($infoB)): $i = 0; $__LIST__ = $infoB;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['id']); ?>"><?php echo ($v['goods_name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?> 
           </select><br />
	商品价格：<input type="text" name="price" value="<?php echo $info['price']; ?>" /><br />
	<img src="/foodshop/Uploads/<?php echo $info[sm_logo]; ?>" />
	商品logo：<input type="file" name="logo" /><br />
	商品描述：<br /><textarea name="goods_desc" id="goods_desc" style="width:600px;height:300px" value="<?php echo $info['goods_desc']; ?>"><?php echo $info['goods_desc']; ?></textarea><br />
	是否上架：
	<input type="radio" name="is_on_sale" value="1" <?php if($info['is_on_sale']==1) echo 'checked="checked"'; ?> />上架
	<input type="radio" name="is_on_sale" value="0" <?php if($info['is_on_sale']==0) echo 'checked="checked"'; ?> />下架
	<br />
	<input type="submit" value="提交">
</form>
</body>
</html>