<?php
namespace Admin\Controller;
use Think\Controller;
class ManagerController extends Controller {
	public function login(){
		if(IS_POST)
		{
			$model = D('Manager');
			if($model->validate($model->_login_validate)->create($_POST)){
               if(TRUE === $model->login()){
               	redirect(U('Admin/Index/index'));//直接跳转
               }
			}
			$error = $model->getError();
			//$this->error($error,'',TRUE);
			$this->error($error);
		}
		$this->display();
	}

    public function showlist(){
      $model = D('Manager');
      //获取带翻页的数据
      $info = $model->select();
      $this->assign('info',$info);
      $this->display();
  }

	public function chkcode(){
		$Verify = new \Think\Verify(array(
			 'length' => 4,
			 'useNoise' => FALSE,
			)); 
		$Verify->entry();
	}

	public function delete(){
       $model = D('Manager');
      //$model -> delete(I('get.id'));
       $id=I('get.id'); 
      //$arr = $model -> getSubIds($id);
      $model -> delete(I('get.id'));
      $this -> success('删除成功',U('showlist'));
  }

  public function tianjia(){
		$manager = D('Manager');
        if(!empty($_POST)){
        	//通过saveData方法制作权限的“auth_path”和“auth_level”进而实现整条记录的存储
        	$info = $manager->create(); //过滤非法字段
        	$time = time();
        	$info['mg_time'] = date("y-m-d",$time);
        	$info['mg_pwd']=md5($password.C('MD5_KEY'));
        	if($manager->add($info)){
        		$this->redirect('showlist');
        	}else{
        		echo "fail";
        	}
        }
        $role = M('Role');
        $info=$role->select();
        $this->assign('info',$info);
		$this->display(); 
	}

}