<?php
namespace Admin\Controller;
use Think\Controller;
class GoodsController extends IndexController {

    public function test(){
       $this->setPageBtn('标题','按钮名称',U(lst));
       $this->display();
    }

    public function add(){ 
      $model = D('Goods');
    	if(IS_POST){
          if($model->create()){
          	if($model->add()) 
          	{
          		$this->success('操作成功','lst');
          		exit;
          	}
          }
         $error = $model->getError();
         $this -> error($error);
       }

       $info=$model->select();
       $this->assign('info',$info);
       $this->display();
    }


  public function edit(){
    //处理表单
    if(IS_POST){
      $model = D('Goods');
      if($model->create(I('post.'),2)){
        //插入数据库
        //save方法的返回值是影响的记录数（mysql_affected_row）,如果修改时没有修改任何值会返回0，如果失败返回FALSE
        if(FALSE !== $model->save()){
          //提示信息
          $this->success('操作成功',U('lst?p='.I('get.p')));
          exit;
        }
      }
      //如果失败显示错误信息
      $this -> error($model->getError());
    }
    //接收商品的ID
    $id = I('get.id');
    //先从数据库中取出要修改的记录的信息
    $model = M('Goods');
    $info = $model->find($id);
    $parent_id = $info['parent_id'];
    $infoA = $model->find($parent_id);
    $infoB = $model->select();
    $this -> assign('info',$info);
    $this -> assign('infoA',$infoA);
    $this -> assign('infoB',$infoB);
    //显示修改的表单
    $this -> display();
  }

  public function delete(){
    $model = D('Goods');
    //$model -> delete(I('get.id'));
    $id=I('get.id');
    $arr = $model -> getSubIds($id);
    if(!$arr){
        $model -> delete(I('get.id'));
        $this -> success('删除成功',U('lst?p='.I('get.p')));
      }else{
        $this -> error('删除失败，请先删除其子节点');
      }
  }

  public function lst(){
  	  $model = D('Goods');
  	  //获取带翻页的数据
  	  $data = $model->search();
  	  $this->assign(array(
  	  	'data' => $data[data],
  	  	'page' => $data[page],
  	  	));
  	  $this->display();
  }

  public function showimg(){
  	$model = D('Goods');
  	$img = $model->img();
  }

  public function category(){
    $goods = D('Goods');
    $data = $goods->select();
    $data=$goods->tree($data);
    $this->assign('data',$data);
    $this->display();
  }

}