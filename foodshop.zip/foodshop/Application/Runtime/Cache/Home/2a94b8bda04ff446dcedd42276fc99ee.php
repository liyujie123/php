<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="/www/foodshop/Public/Home/js/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="/www/foodshop/Public/Home/js/index.js"></script>
<link href="/www/foodshop/Public/Home/css/index.css" rel="stylesheet" type="text/css">
<title>美食窝-首页</title>
</head>
<body>
<div id="Layer0"  align="center">
<div id="Layer1">
  <div id="Layer2">
    <div id="Layer3">
	   <div id="Layer4b"><a href="/foodshop/index.php/home/index/denglu.html" target="_blank">登陆页面</a></div>
      <div id="Layer4">您好:<?php echo (session('user')); ?></div>
	  <div id="Layer4a"><a onclick="if(confirm('确定要退出吗？')) return true; else return false;" href="/www/foodshop/index.php/Home/Index/logout">退出登陆</a></div>
      <div id="Layer5"><a href="/foodshop/index.php/home/index/zhuce.html" target="_blank">免费注册</a></div>
      <div id="Layer6"><a href="/foodshop/index.php/home/index/usershow1.html" target="_blank">个人中心</a></div>
      <div id="Layer7"><a href="#">关注食窝</a></div>
      <div id="Layer8"><a href="#">客户服务</a></div>
      <div id="Layer9"><a href="/foodshop/index.php/home/index/sss.html" target="_blank">网站导航</a></div>
    </div>
  </div>
  <div id="Layer10">
  <img id="img1" src="/www/foodshop/Public/Home/pic/biaoti2.jpg" height="50" width="1280">
  </div>
  <div id="Layer11">
    <div id="Layer12"><img src="/www/foodshop/Public/Home/pic/meishiwo.jpg"></div>
    <div id="Layer13"><form action="/foodshop/index.php/home/index/sousuo" method="post"><input type="text" name="sou" class="sousuo"><input type="submit" name="okok" class="sousuo1" value="搜索"></form></div>
    <div id="Layer14">
      <div id="Layer15"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank">汽水</a></div>
      <div id="Layer16"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank">饼干</a></div>
	  <div id="Layer17"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank">水果</a></div>
      <div id="Layer18"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank">小吃</a></div>
	  <div id="Layer19"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank">外卖</a></div>
    </div>
  </div>
  
  <div id="Layer20">
    <div id="Layer21">
      <div id="Layer22">所有食品分类</div>
      <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank"><div id="Layer23">
        <p>休闲零食</p>
        <p>松子 鲜花饼 腰果</p>
      </div></a>
	  <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank"><div id="Layer24">
	    <p>饼干糕点</p>
	    <p>华夫饼 肉松饼</p>
	  </div></a>
	    <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank">
	    <div id="Layer25">
	    <p>生鲜果蔬</p>
	    <p>文鱼 车厘子 蔬菜</p>
	  </div></a>
	  <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank">
	  <div id="Layer26">
	    <p>粮油干粮</p>
	    <p>大米 食用油 干货</p>
	  </div></a>
	  <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank">
	  <div id="Layer27">
	    <p>茶水饮料</p>
	    <p>酸饮料 果汁 茶叶</p>
	  </div></a>
	  <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank">
	  <div id="Layer28">
	    <p>传统滋补</p>
	    <p>西洋参 燕窝 三七</p>
	  </div></a>
	  <a href="/foodshop/index.php/home/index/goodsshow.html" class="goodslist" target="_blank">
	  <div id="Layer29">
	    <p>中外名酒</p>
	    <p>白酒 黄酒 葡萄酒</p>
	  </div>
    </div>
    <div id="Layer30"><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank"><img id="img2" src="/www/foodshop/Public/Home/pic/zhu1.jpg" width="800" height="425" onmousemove="cancel()" onmouseout="start()"></a></div>
	<div id="Layer30A" onclick="imgA()"><</div>
	<div id="Layer30B" onclick="imgB()">></div>
	<div id="Layer30a">
	     <div id="Layer30aa">美食专区</div>
		 <div id="Layer30ab">数据有点多，在这里就不一一列出来了，点击左边的链接可以跳到相关的链接</div>
	</div>
	<div id="Layer31">
	     <div id="Layer32">&nbsp;<a href="#">美食快报</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">更多>></a></div>
		 <div id="Layer32a">
		 <table>
		   <tr><td style="font-size:13px"><a href="/foodshop/index.php/home/index/newshow.html?id=<?php echo ($info1[0][id]); ?>" target="_blank"><?php echo ($info1[0][tag]); ?> <?php echo ($info1[0][title]); ?></a></td></tr>
		   <tr><td style="font-size:13px"><a href="/foodshop/index.php/home/index/newshow.html?id=<?php echo ($info1[1][id]); ?>" target="_blank"><?php echo ($info1[1][tag]); ?> <?php echo ($info1[1][title]); ?></a></td></tr>
		   <tr><td style="font-size:13px"><a href="/foodshop/index.php/home/index/newshow.html?id=<?php echo ($info1[2][id]); ?>" target="_blank"><?php echo ($info1[2][tag]); ?> <?php echo ($info1[2][title]); ?></a></td></tr>
		   <tr><td style="font-size:13px"><a href="/foodshop/index.php/home/index/newshow.html?id=<?php echo ($info1[3][id]); ?>" target="_blank"><?php echo ($info1[3][tag]); ?> <?php echo ($info1[3][title]); ?></a></td></tr>
		   <tr><td style="font-size:13px"><a href="/foodshop/index.php/home/index/newshow.html?id=<?php echo ($info1[4][id]); ?>" target="_blank"><?php echo ($info1[4][tag]); ?> <?php echo ($info1[4][title]); ?></a></td></tr>
		 </table>
		 </div>
		 <div id="Layer32b">
		 <table>
		  <tr><td align="center">促销会场</td></tr>
		  <tr><td><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank"><img src="/www/foodshop/Public/Home/pic/cx1.jpg" width="200px" height="55px" /></a></td></tr>
		  <tr><td><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank"><img src="/www/foodshop/Public/Home/pic/cx2.jpg" width="200px" height="55px" /></a></td></tr>
		  <tr><td><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank"><img src="/www/foodshop/Public/Home/pic/cx3.jpg" width="200px" height="55px" /></a></td></tr>
		  <tr><td><a href="/foodshop/index.php/home/index/goodsshow.html" target="_blank"><img src="/www/foodshop/Public/Home/pic/cx4.jpg" width="200px" height="55px" /></a></td></tr>
		 </table>
		 </div>
    </div>
  </div>
  <div id="Layer33">美食推荐</div>
  <div id="Layer34">
           <div id="Layer35">
		        <div id="Layer35a"><img src="/www/foodshop/Uploads/<?php echo ($info[0][logo]); ?>" width="240px" height="200px"></div>
				<div id="Layer35b">￥<?php echo ($info[0][price]); ?></div>
				<div id="Layer35c">数量：<?php echo ($info[0][goods_count]); ?></div>
				<div id="Layer35d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[0][id]); ?>" class="goods" target="_blank"><?php echo ($info[0][goods_desc]); ?></a></div>
		   </div>   
		<div id="Layer36">
		       <div id="Layer36a"><img src="/www/foodshop/Uploads/<?php echo ($info[1][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer36b">￥<?php echo ($info[1][price]); ?></div>
				<div id="Layer36c">数量：<?php echo ($info[1][goods_count]); ?></div>
				<div id="Layer36d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[1][id]); ?>" class="goods" target="_blank"><?php echo ($info[1][goods_desc]); ?></a></div>
		</div>
		<div id="Layer37">
		      <div id="Layer37a"><img src="/www/foodshop/Uploads/<?php echo ($info[2][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer37b">￥<?php echo ($info[2][price]); ?></div>
				<div id="Layer37c">数量：<?php echo ($info[2][goods_count]); ?></div>
				<div id="Layer37d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[2][id]); ?>" class="goods" target="_blank"><?php echo ($info[2][goods_desc]); ?></a></div>
		</div>
		<div id="Layer38">
		     <div id="Layer38a"><img src="/www/foodshop/Uploads/<?php echo ($info[3][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer38b">￥<?php echo ($info[3][price]); ?></div>
				<div id="Layer38c">数量：<?php echo ($info[3][goods_count]); ?></div>
				<div id="Layer38d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[3][id]); ?>" class="goods" target="_blank"><?php echo ($info[3][goods_desc]); ?></a></div>
		</div>
		<div id="Layer39">
		     <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[4][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[4][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[4][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[4][id]); ?>" class="goods" target="_blank"><?php echo ($info[4][goods_desc]); ?></a></div>
		</div>
		<div id="Layer40">
		      <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[5][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[5][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[5][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[5][id]); ?>" class="goods" target="_blank"><?php echo ($info[5][goods_desc]); ?></a></div>
		</div>
		<div id="Layer41">
		       <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[6][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[6][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[6][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[6][id]); ?>" class="goods" target="_blank"><?php echo ($info[6][goods_desc]); ?></a></div>
		</div>
		<div id="Layer42">
		        <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[7][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[7][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[7][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[7][id]); ?>" class="goods" target="_blank"><?php echo ($info[7][goods_desc]); ?></a></div>
		</div>
		<div id="Layer43">
		      <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[8][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[8][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[8][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[8][id]); ?>" class="goods" target="_blank"><?php echo ($info[8][goods_desc]); ?></a></div>
		</div>
		<div id="Layer44">
		       <div id="Layer39a"><img src="/www/foodshop/Uploads/<?php echo ($info[9][logo]); ?>" width="240px" height="200px"> </div>
				<div id="Layer39b">￥<?php echo ($info[9][price]); ?></div>
				<div id="Layer39c">数量：<?php echo ($info[9][goods_count]); ?></div>
				<div id="Layer39d"><a href="/foodshop/index.php/home/index/gouwu.html?id=<?php echo ($info[9][id]); ?>" class="goods" target="_blank"><?php echo ($info[9][goods_desc]); ?></a></div>
		</div>
  </div>
  <div id="Layer45">
	      <div id="Layer45a"><a href="#">关于我们</a></div>
		  <div id="Layer45b"><a href="#">友情链接</a></div>
		  <div id="Layer45c"><a href="#">人才招聘</a></div>
		  <div id="Layer45d"><a href="#">合作团队</a></div>
		  <div id="Layer45e"><a href="#">技术中心</a></div>
		  <div id="Layer45f"><a href="#">加盟好友</a></div>
		  <div id="Layer45g"><a href="#">联系方式</a></div>
		  <div id="Layer45h">开发者：李宇杰&nbsp;&nbsp;&nbsp;&nbsp;620022430@qq.com&nbsp;&nbsp;&nbsp;&nbsp;版权所有</div>
	   </div>
    </div>
</div>
</body>
</html>