<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<script type="text/javascript" src="/foodshop/Public/jQuery_calendar/js/jquery.js"></script>
<title></title>
</head>
<body>
<table>
<form name="main_form" method="post" action="/foodshop/index.php/Admin/Auth/tianjia">
	<tr><td>权限名称：</td><td><input type="text" name="auth_name" /></td></tr>
	<tr><td>父id：</td><td><select name="auth_pid">
           <option value="0">-请选择-</option>
           <?php if(is_array($auth_p_info)): $i = 0; $__LIST__ = $auth_p_info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['auth_id']); ?>"><?php echo ($v['auth_name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?> 
  </select></td></tr>
	<tr><td>控制器：</td><td><input type="text" name="auth_c" /></td></tr>
	<tr><td>操作方法：</td><td><input type="text" name="auth_a" /></td></tr>
	<tr><td><input type="submit" value="添加"></td>
  </form>
</table>
</body>
</html>