<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>会员名称</td>
		<td>会员密码</td>
		<td>会员邮箱</td>
		<td>会员密保</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['username']); ?></td>
		<td><?php echo ($v['password']); ?></td>
		<td><?php echo ($v['email']); ?></td>
		<td><?php echo ($v['mm']); ?></td>
		<td>
		<a href="#" >修改</a>
		<a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['id']); ?>"  >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>