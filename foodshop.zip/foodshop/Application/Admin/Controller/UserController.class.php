<?php
namespace Admin\Controller;
use Think\Controller;
class UserController extends Controller {

    public function showlist(){
      $model = D('User');
      //获取带翻页的数据
      $info = $model->select();
      $this->assign('info',$info);
      $this->display();
  }

	public function delete(){
       $model = D('User');
      //$model -> delete(I('get.id'));
       $id=I('get.id'); 
      //$arr = $model -> getSubIds($id);
      $model -> delete($id);
      $this -> success('删除成功',U('showlist'));
  }

}