<?php
namespace Admin\Controller;
use Think\Controller;
class OrderController extends IndexController {
     public function showlist(){
      $model = D('userlist');
      //获取带翻页的数据
      $info = $model->select();
      $this->assign('info',$info);
      $this->display();
  }


  public function search(){
       $model = D('userlist');
       if(IS_POST){
         $data = I('post.');
		 $username=$data['username'];
		 $goods_name=$data['goods_name'];
		 if($username && !$goods_name){
		    $arr1['username']=$username;
            $info = $model->where($arr1)->select();
		    $this->assign('info',$info);
		 }
		 if($goods_name && !$username){
		    $arr2['goods_name']=$goods_name;
            $info = $model->where($arr2)->select();
		    $this->assign('info',$info);
		 }
		 if($username && $goods_name){
		    $arr3['goods_name']=$goods_name;
			$arr3['username']=$username;
            $info = $model->where($arr3)->select();
		    $this->assign('info',$info);
		 }
        }
		$this->display(); 
  }

  public function delete(){
    $model = D('userlist');
    //$model -> delete(I('get.id'));
    $id=I('get.id');
    //$arr = $model -> getSubIds($id);
    $model -> delete(I('get.id'));
    $this -> success('删除成功',U('showlist'));
  }

  public function edit(){
    //处理表单
    if(IS_POST){
      $model = M('userlist');
      if($update=$model->create(I('post'))){
        //var_dump($update);
        $sql = "update shop_userlist set goods_count='$update[goods_count]',pricecount='$update[pricecount]' where orderid='$update[id]'";
        if($model->execute($sql)){
          $this->success('操作成功',U('showlist'));
          exit;
        }
      }
      //如果失败显示错误信息
      $this -> error($model->getError());
    }
    //接收商品的ID
    $id = I('get.id');
    //先从数据库中取出要修改的记录的信息
    $model = M('userlist');
    $info = $model->find($id);
    $this -> assign('info',$info);
    //显示修改的表单
    $this -> display();
  }

}