// JavaScript Document

function yanzheng(){
	     username = document.getElementById("username").value;
		 password1 = document.getElementById("password1").value;
		 password2 = document.getElementById("password2").value;
		 email = document.getElementById("email").value;
		 mm = document.getElementById("mm").value;
		 var re = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
		 if(username==""||password1==""||password2==""||email==""||mm==""){
		    alert('以上信息都必须填写，不能为空！');
			return false;
		 }
		 if(username.length>20){
			 alert('用户名不能超过20个字符！');
			 return false;
			 }
		 if(password1.length<6||password1.length>20){
		     alert('密码位数为6位至20位之间！');
			 return false;
		 }
		 if(password1!=password2){
		    alert('密码与确认密码不一致！');
			return false;
		 }
		 if(!email.match(re)){
		    alert('邮箱格式不对');
			return false;
		 }
		 if(email.length>20){
			 alert('邮箱字段不能超过20个字符！');
			 return false;
			 }
		 if(mm.length<6||mm.length>20){
		    alert('密保位数为6位至20位之间！');
			return 0;
		 }
	   }


function checkname(){
		//ajax负责抓取用户名信息，传给服务器进行校验
		
		//获得用户名信息
		var nm = document.getElementById('username').value;
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function(){
			if(xhr.readyState==4){
			   var value = xhr.responseText;
			   if(value==1){alert('该用户名已存在！');}
			   else{
			    var	duiimg = document.getElementById('duiimg');
			    duiimg.style.visibility="visible";}
			}
		}
		xhr.open('get','/foodshop/index.php/home/index/zhuce?name='+nm);
		xhr.send(null);
	}


	function nonono(){
		        var	duiimg = document.getElementById('duiimg');
			    duiimg.style.visibility="hidden";
	           }