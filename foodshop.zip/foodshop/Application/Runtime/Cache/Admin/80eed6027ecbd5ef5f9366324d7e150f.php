<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset=utf8>
<title></title>
</head>
<body>
<form method="post" action="/foodshop/index.php/Admin/New/edit/id/1.html" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
	公告类型：<select name="tag">
              <option value="<?php echo $info['tag']; ?>"> <?php echo $info['tag']; ?> </option>
              <option value="[公告]">公告</option>
              <option value="[特惠]">特惠</option>
              <option value="[文章]">文章</option>
              <option value="[新闻]">新闻</option>
           </select><br />
	公告标题：<input type="text" name="title" value="<?php echo $info['title']; ?>" /><br />
	公告内容：<br /><textarea name="content" style="width:600px;height:300px" value="<?php echo $info['content']; ?>"><?php echo $info['content']; ?></textarea><br />
	<input type="submit" value="提交">
</form>
</body>
</html>