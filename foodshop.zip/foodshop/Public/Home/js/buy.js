function f1(){
		var price = document.getElementById('price');
		var str2 = document.getElementById('str2');
		var count = document.getElementById('count');
		var goodscount = document.getElementsByTagName('input')[4];
		var pricecount = document.getElementsByTagName('input')[5];
		var pri=price.innerHTML;
		var str=str2.innerHTML;
		var cou=count.innerHTML;
		if(str==1){
          str=1
		}else{
		str = str-1;
		str2.innerHTML=str;
		goodscount.value=str;
		cou = cou-pri;
		count.innerHTML=cou;
		pricecount.value=cou;
		}
	}
	function f2(){
		var price = document.getElementById('price');
		var str2 = document.getElementById('str2');
		var count = document.getElementById('count');
		var goodscount = document.getElementsByTagName('input')[4];
		var pricecount = document.getElementsByTagName('input')[5];
		var pri=price.innerHTML;
		var str=parseFloat(str2.innerHTML);
		var cou=count.innerHTML;
		var st = parseFloat(1);
		if(str==10){
          str=10
		}else{
		str = parseFloat(str+st);
		str2.innerHTML=str;
		goodscount.value=str;
		cou = str*pri
		count.innerHTML=cou;
		pricecount.value=cou;
		}
	}