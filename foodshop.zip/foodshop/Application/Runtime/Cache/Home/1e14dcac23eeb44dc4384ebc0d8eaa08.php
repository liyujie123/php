<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/foodshop/Public/Home/css/usershow2.css" rel="stylesheet" type="text/css">
<title>个人中心</title>
</head>
<body>
<div id="Layer0"  align="center">
    <div id="Layer1">
	   <div id="Layer2">
       <div id="Layer3">
	   <div id="Layer4b"><a href="/foodshop/index.php/home/index/denglu.html">登陆页面</a></div>
      <div id="Layer4">您好:<?php echo (session('user')); ?></div>
	  <div id="Layer4a"><a onclick="if(confirm('确定要退出吗？')) return true; else return false;" href="/foodshop/index.php/Home/Index/logout">退出登陆</a></div>
      <div id="Layer5"><a href="/foodshop/index.php/home/index/zhuce.html">免费注册</a></div>
      <div id="Layer6"><a href="#">个人中心</a></div>
      <div id="Layer7"><a href="#">关注食窝</a></div>
      <div id="Layer8"><a href="#">客户服务</a></div>
      <div id="Layer9"><a href="#">网站导航</a></div>
      </div>
      </div>
	  <div id="Layer10">
	     <div id="Layer10-1"><img src="/foodshop/Public/Home/pic/meishiwo.jpg" width="60px" height="60px" /></div>
		 <div id="Layer10-2">个人中心</div>
		 <a href="/foodshop/index.php/home/index/index.html"><div id="Layer10-3">首页</div></a>
		 <form action="/foodshop/index.php/home/index/sousuo" method="post">
		 <div id="Layer10-4"><table><tr><td><input type="text" value="零食" class="text" name="sou" /></td><td style="background-color:#eeeeee; color:#666666; font-size:14px" width="50px" align="center"><input type="submit" name="okok" value="搜索" class="text2" /></td></tr></table></div>
		 <form>
	  </div>
	  <div id="Layer11">
	     <a href="/foodshop/index.php/home/index/usershow1.html"><div id="Layer11-1">个人资料</div></a>
		 <a href="/foodshop/index.php/home/index/usershow2.html"><div id="Layer11-2">已买宝贝</div></a>
		 <a href="#"><div id="Layer11-3">商城积分</div></a>
		 <a href="#"><div id="Layer11-4">......</div></a>
	  </div>
	  <div id="Layer12">
	  <div id="Layer12-1">订单详情</div>
	  <br /><br /><br />
	     <table align="center" border="1px">
          <tr align="center"><td>商品名称</td><td>商品描述</td><td>商品价格</td><td>购买数量</td><td>总付金额</td></tr>
          <?php if(is_array($info)): foreach($info as $key=>$v): ?><tr align="center"><td><?php echo ($v["goods_name"]); ?></td><td><?php echo ($v["goods_desc"]); ?></td><td><?php echo ($v["price"]); ?></td><td><?php echo ($v["goods_count"]); ?></td><td><?php echo ($v["pricecount"]); ?></td><?php endforeach; endif; ?>
          </table>
	  </div>
    </div>
</div>
</body>
</html>