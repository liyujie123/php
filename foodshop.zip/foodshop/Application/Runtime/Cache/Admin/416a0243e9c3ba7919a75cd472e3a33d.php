<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title></title>
</head>
<body>
<br />
<div style="text-align:right"><a href="/foodshop/index.php/Admin/New/add" style="font-size:20px;">添加公告</a></div>
<form>
<table width="100%" cellpadding="5" cellspacing="5" border="1px">
	<tr>
		<td>公告的id</td>
		<td>公告类型</td>
		<td>公告标题</td>
		<td>公告内容</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($v['id']); ?></td>
		<td><?php echo ($v['tag']); ?></td>
		<td><?php echo ($v['title']); ?></td>
		<td>请在修改处查看...</td>
		<td>
		<a href="<?php echo U('edit?id='.$v['id']); ?>" >修改</a>
		<a onclick="return confirm('确定要删除吗？');" href="<?php echo U('delete?id='.$v['id']); ?>"  >删除</a>
		</td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>