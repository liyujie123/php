<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登陆页面</title>
<script type="text/javascript" src="/foodshop/Public/Home/js/denglu.js"></script>
<link href="/foodshop/Public/Home/css/denglu.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="Layer0" align="center">
<div id="Layer1">
    <div id="Layer2">
	   <div id="Layer2a">美食窝，一家专卖美食的网站商城！</div>
	   <div id="Layer2b"><a href="/foodshop/index.php">商城首页</a></div>
	   <div id="Layer2c"><a href="/foodshop/index.php">商城详情</a></div>
	</div>
	<div id="Layer3">
	  <img src="/foodshop/Public/Home/pic/t0141372f8fb072b9ea.png" width="1280" height="380" />
	  <div id="Layer3a">
	       <form action="#" method="post">
		  <div id="Layer3aa">会员登录</div>
		  <div id="Layer3ab">用户名&nbsp;<input type="text" id="username" name="username"></div>
		  <div id="Layer3ac">密&nbsp;&nbsp;码&nbsp;<input type="password" id="password" name="password"></div>
		  <div id="Layer3ad">验证码&nbsp;<input type="text" id="yan" name="yan"></div>
		  <div id="Layer3ae"><img name="v" src="/foodshop/index.php/home/index/verifyimg"></div>
		  <div id="Layer3af"><p onclick="v.src='/foodshop/index.php/home/index/verifyimg/'+Math.random()">看不清 </p>
		  </div>
		  <div id="Layer3ag"><input type="submit" name="ok" class="denglu" value="登陆" onclick="yanzheng()"></div>
		  </form>
		  <div id="Layer3ah"><a href="#">忘记密码？</a></div>
		  <div id="Layer3ai"><a href="zhuce.html">立即注册</a></div>
	  </div>
  </div>
   <div id="Layer4">
	      <div id="Layer4a"><a href="#">关于我们</a></div>
		  <div id="Layer4b"><a href="#">友情链接</a></div>
		  <div id="Layer4c"><a href="#">人才招聘</a></div>
		  <div id="Layer4d"><a href="#">合作团队</a></div>
		  <div id="Layer4e"><a href="#">技术中心</a></div>
		  <div id="Layer4f"><a href="#">加盟好友</a></div>
		  <div id="Layer4g"><a href="#">联系方式</a></div>
		  <div id="Layer4h">开发者：李宇杰&nbsp;&nbsp;&nbsp;&nbsp;620022430@qq.com&nbsp;&nbsp;&nbsp;&nbsp;版权所有</div>
	   </div>
  </div>
</div>
</body>
</html>